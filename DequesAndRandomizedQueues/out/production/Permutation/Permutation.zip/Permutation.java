import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

/**
 * The client class takes an integer k as a command-line argument; reads a sequence of strings from standard input using StdIn.readString(); and prints exactly k of them, uniformly at random. Print each item from the sequence at most once.
 */

public class Permutation {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]), i = 0;
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        while (!StdIn.isEmpty()) {
            if (i > k) {
                if (StdRandom.uniform(i) < k) rq.dequeue();
            }
            rq.enqueue(StdIn.readString());
            i++;
        }
        for (int j = 0; j < k; j++) {
            StdOut.println(rq.dequeue());
        }
    }
}
